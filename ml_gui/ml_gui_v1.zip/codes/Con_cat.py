#!/usr/bin/env python
# coding: utf-8

# In[2]:


from sklearn.preprocessing import LabelEncoder
import pandas as pd


# In[ ]:





# In[ ]:





# In[ ]:





# In[6]:


def con_cat(df):
    
    return le.fit_transform(df)


# In[ ]:




